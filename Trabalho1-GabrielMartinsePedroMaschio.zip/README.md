# Trabalho 1 - Segurança Computacional

Para a execução do Trabalho 1, basta abrir um terminal na pasta que contém os arquivos e executar o comando:

```
python3 Main.py
```

Caso não tenha o Python instalado, é possível obter instruções de instalação para diversos Sistemas Operacionais [aqui](https://www.python.org/downloads/).

Para adicionar arquivos cifrados para serem quebrados, é preciso colocá-los na mesma pasta que contém os códigos-fonte.